# Installer file for WeatherLink Live (WeatherLinkLiveUDP) driver for WeeWX
# Copyright 2020 Bastiaan Meelberg
# Modified 2022/2025 Werner Krenn (leaf/soil/Extra2..4,ISS2,Wind,Rain,Batlevel,Signal)
# Distributed under the terms of the GNU Public License (GPLv3)
# Set this station:  sudo weectl station reconfigure --driver user.weatherlinkliveudp

import configobj
from setup import ExtensionInstaller

from six.moves import StringIO

# WeeWX imports
import weewx

def loader():
    return weatherlinkliveudpInstaller()

class weatherlinkliveudpInstaller(ExtensionInstaller):
    def __init__(self):
        super(weatherlinkliveudpInstaller, self).__init__(
            version='0.6.3',
            name='WeatherLinkLiveUDP',
            description='Periodically poll weather data from a WeatherLink Live device',
            author="Werner Krenn",
            #data_services=user.davishealthapi.DavisHealthAPI,
            #data_services=user.airlink.AirLink, user.davishealthapi.DavisHealthAPI,
            #process_services = weewx.engine.StdConvert, weewx.engine.StdCalibrate, weewx.engine.StdQC, weewx.wxservices.StdWXCalculate, user.sunrainduration.SunshineDuration,
            #xtype_services = weewx.wxxtypes.StdWXXTypes, weewx.wxxtypes.StdPressureCooker, weewx.wxxtypes.StdRainRater, weewx.wxxtypes.StdDelta, user.GTS.GTSService
            config={
                'Station': {
                    'station_type_new': 'WeatherLinkLiveUDP',
                },
                'Engine': {
                    'Services': {

                        "data_services_new" : 'user.airlink.AirLink, user.davishealthapi.DavisHealthAPI,',
                        "process_services_new" : 'weewx.engine.StdConvert, weewx.engine.StdCalibrate, weewx.engine.StdQC, weewx.wxservices.StdWXCalculate, user.sunrainduration.SunshineDuration,',
                    }
                },
                'DataBindings': {
                    'wx_binding': {
                        'database': 'archive_sqlite',
                        'database_new': 'archive_sqlite',
                        'table_name': 'archive',
                        'manager': 'weewx.manager.DaySummaryManager',
                        'schema': 'schemas.wview_extendedmy.schema',
                        'schema_new': 'schemas.wview_extendedmy.schema',
                    },
                    'davishealthapi_binding': {
                        'database' : 'davishealthapi_sqlite',
                        'table_name' : 'archive',
                        'manager' : 'weewx.manager.DaySummaryManager',
                        'schema' : 'user.davishealthapi.schema',
                    },
                },
                'Databases': {
                    'archive_sqlite': {
                        'database_type': 'SQLite',
                        'database_name': 'weewx_wlludp.sdb',
                        'database_name_new': 'weewx_wlludp.sdb',
                    },
                    'davishealthapi_sqlite': {
                        'database_type': 'SQLite',
                        'database_name': 'davishealthapi.sdb',
                    },
                },
                'StdReport': {
                    'SeasonsReport': {
                        'enable': 'false',
                        'HTML_ROOT': '/var/www/html/weewx/old',
                    },
                    'SeasonsDavis': {
                        'skin': 'SeasonsDavis',
                        'lang': 'de',
                        'enable': 'true',
                        'HTML_ROOT': '/var/www/html/weewx',
                    },
                    'DavisHealth': {
                        'skin': 'health',
                        'lang': 'en',
                        'enable': 'false',
                        'HTML_ROOT': '/var/www/html/weewx/health',
                    },
                    'Airlink': {
                        'skin': 'airlink',
                        'lang': 'en',
                        'enable': 'false',
                        'HTML_ROOT': '/var/www/html/weewx/airlink',
                    },
                },
                'WeatherLinkLiveUDP': {
                    '# set this station': 'sudo weectl station reconfigure --driver user.weatherlinkliveudp',
                    'wll_ip': '192.2.3.4',
                    'poll_interval': 30,
                    'driver': 'user.weatherlinkliveudp',
                    'txid_iss' : 1,
                    'extra_id': 0,
                    'extra_id2': 0,
                    'extra_id3': 0,
                    'extra_id4': 0,
                    'leaf': 0,
                    'soil': 0,
                    'wind': 0,
                    'txid_rain' : 0,
                    'txid_iss2' : 0,
                    '#did' : '001D0A61F5E8',
                    'log': 0,
                },
                'davishealthapi': {
                    'data_binding': 'davishealthapi_binding',
                    'station_id': '?????',
                    'api_key': 'abcdefghijklmnopqrstuvwzyx123456',
                    'api_secret': '123456abcdefghijklmnopqrstuvwxyz',
                    'max_age': 'None',
                    'packet_log': 0,
                    '#0': '0 = first check and log available sensortypes once at start,  5= log all (packets ...)',
                    '#max_count': '13',
                    'sensor_tx1': '0',
                    'sensor_tx2': '0',
                    'sensor_tx3': '0',
                    'sensor_tx4': '0',
                    'sensor_tx5': '0',
                    'sensor_tx6': '0',
                    'sensor_tx7': '0',
                    'sensor_tx8': '0',
                },
                'AirLink': {
                    'Sensor1'  : {
                        'enable'     : False,
                        'hostname'   : '192.168.0.201',
                        'port'       : '80',
                        'wait_before_retry' : '15',
                        'timeout'    : '2',
                    },
                    'Sensor2': {
                        'enable'     : False,
                        'hostname'   : 'airlink2',
                        'port'       : '80',
                        'timeout'    : '2',
                     },
                },
                'RadiationDays': {
                    'min_sunshine': '120',
                    'sunshine_coeff': '0.90',
                    'sunshine_min': '18',
                    'sunshine_loop': '1',
                    'rainDur_loop': '0',
                    'sunshine_log': '0',
                    'rainDur_log': '0',
                    'rain2': '1',
                    'sunshine2': '0',
                    'sunshine2_loop': '1',
                    'rainDur2_loop': '0',
                    'sunshine2_log': '0',
                    'rainDur2_log': '0',
                },
            },
            files=[
                ('bin/user', [
                    'bin/user/weatherlinkliveudp.py',
                    'bin/user/davishealthapi.py',
                    'bin/user/historygenerator3.py',
                    'bin/user/historygenerator42.py',
                    'bin/user/sunevents.py',
                    'bin/user/sunrainduration.py',
                    'bin/user/airlink.py',
                    'bin/user/davis_api_tool.py',
                    'bin/user/add_extrawll2_to_extended.sh',
                    'bin/user/add_extrawll_to_extended.sh',
                ]),
                ('bin/schemas', [
                    'bin/schemas/wview_extended2my.py',
                    'bin/schemas/wview_extendedmy.py',
                ]),
                ('skins', [
                    'skins/SeasonsDavis/index.html.tmpl',
                    'skins/SeasonsDavis/telemetry.html.tmpl',
                    'skins/SeasonsDavis/celestial.html.tmpl',
                    'skins/SeasonsDavis/rss.xml.tmpl',
                    'skins/SeasonsDavis/statistics.html.tmpl',
                    'skins/SeasonsDavis/tabular.html.tmpl',
                    'skins/SeasonsDavis/skin.conf',
                    'skins/SeasonsDavis/seasons.css',
                    'skins/SeasonsDavis/seasons.js',
                    'skins/SeasonsDavis/current.inc',
                    'skins/SeasonsDavis/hilo.inc',
                    'skins/SeasonsDavis/statistics.inc',
                    'skins/SeasonsDavis/sensors.inc',
                    'skins/SeasonsDavis/about.inc',
                    'skins/SeasonsDavis/titlebar.inc',
                    'skins/SeasonsDavis/analytics.inc',
                    'skins/SeasonsDavis/celestial.inc',
                    'skins/SeasonsDavis/identifier.inc',
                    'skins/SeasonsDavis/map.inc',
                    'skins/SeasonsDavis/sunmoon.inc',
                    'skins/SeasonsDavis/radar.inc',
                    'skins/SeasonsDavis/satellite.inc',
                    'skins/SeasonsDavis/mobile.inc',
                    'skins/SeasonsDavis/neowx.inc',
                    'skins/SeasonsDavis/belchertown.inc',
                    'skins/SeasonsDavis/amphibian.inc',
                    'skins/SeasonsDavis/smartphone.inc',
                    'skins/SeasonsDavis/cmon.inc',
                    'skins/SeasonsDavis/health.inc',
                    'skins/SeasonsDavis/favicon.ico',
                    'skins/SeasonsDavis/Batt0.png',
                    'skins/SeasonsDavis/Batt1.png',
                    'skins/SeasonsDavis/Batt2.png',
                    'skins/SeasonsDavis/Batt3.png',
                    'skins/SeasonsDavis/Batt4.png',
                    'skins/SeasonsDavis/Batt5.png',
                    'skins/SeasonsDavis/Batt6.png',
                    'skins/SeasonsDavis/Batt6x.png',

                    'skins/SeasonsDavis/lang/de.conf',
                    'skins/SeasonsDavis/lang/en.conf',
                    'skins/SeasonsDavis/NOAA/NOAA-%Y.txt.tmpl',
                    'skins/SeasonsDavis/NOAA/NOAA-%Y-%m.txt.tmpl',
                    'skins/SeasonsDavis/font/license.txt',
                    'skins/SeasonsDavis/font/OFL.txt',
                    'skins/SeasonsDavis/font/OpenSans.woff2',
                    'skins/SeasonsDavis/font/OpenSans.woff',
                    'skins/SeasonsDavis/font/OpenSans-Bold.ttf',
                    'skins/SeasonsDavis/font/OpenSans-Regular.ttf',
                    'skins/SeasonsDavis/font/Kanit-Bold.ttf',
                    'skins/SeasonsDavis/font/Kanit-Regular.ttf',

                    'skins/health/index.html.tmpl',
                    'skins/health/skin.conf',
                    'skins/health/health.css',
                    'skins/health/health.js',
                    'skins/health/favicon.ico',
                    'skins/health/identifier.inc',
                    'skins/health/sensors.inc',
                    'skins/health/sensorsair.inc',
                    'skins/health/titlebar.inc',
                    'skins/health/lang/de.conf',
                    'skins/health/lang/en.conf',
                    'skins/airlink/index.html.tmpl',
                    'skins/airlink/skin.conf',
                    'skins/airlink/favicon.ico',
                    'skins/airlink/titlebar.inc',
                ]),
            ],
        )
